/*
 * Enterprise Architect - JScript : Diagrama de Clases
 *   G06 Diagrama de clases - Servicios (Framework)
 * ANTES DE EJECUTAR: cerra los diagramas abiertos en EA.
 * Re-ejecutable: si existe un diagrama con el mismo nombre en el paquete, lo borra y lo rehace.
 * USO: selecciona el paquete en el Browser -> Specialize > Scripting > New JScript Script ->
 *      pega todo -> Run Script. Al final hace auto-layout.
 */
!INC Local Scripts.EAConstants-JScript

var DIAG_NOMBRE = "G06 Diagrama de clases - Servicios (Framework)";
var ELEMS = [{"name": "DV_43BO", "kind": "Class", "attrs": [["NombreTabla_43BO", "string"], ["DVH_43BO", "long"], ["DVV_43BO", "long"]], "meths": []}, {"name": "User_43BO", "kind": "Class", "attrs": [["Nombre_43BO", "string"], ["DNI_43BO", "int"], ["Apellido_43BO", "string"], ["Email_43BO", "string"], ["Hash_43BO", "string"], ["Bloqueado_43BO", "bool"], ["Activo_43BO", "bool"], ["Idioma_43BO", "string"]], "meths": []}, {"name": "Modulo_43BO", "kind": "Class", "attrs": [], "meths": []}, {"name": "Evento_43BO", "kind": "Class", "attrs": [], "meths": []}, {"name": "Bitacora_43BO", "kind": "Class", "attrs": [["Fecha_43BO", "DateTime"], ["Criticidad_43BO", "int"]], "meths": []}, {"name": "Permisos_43BO", "kind": "Class", "attrs": [], "meths": []}, {"name": "SessionManager_43BO", "kind": "Class", "attrs": [["Permisos", "string"], ["idioma", "string"]], "meths": [["IniciarSesion_43BO", "void", 3], ["CerrarSesion_43BO", "void", 0], ["ActualizarIdioma", "void", 1]]}, {"name": "CriptoManager_43BO", "kind": "Class", "attrs": [["Clave_43BO", "byte"], ["IV_43BO", "byte"]], "meths": [["GenerarHash_43BO", "string", 1], ["Encriptar_43BO", "string", 1], ["Desencriptar_43BO", "string", 1]]}, {"name": "GestorArchivosIdioma_43BO", "kind": "Class", "attrs": [], "meths": [["ObtenerContenidoJson_43BO", "string", 1]]}, {"name": "IdiomaObserver_43BO", "kind": "Interface", "attrs": [], "meths": []}, {"name": "GestorIdioma_43BO", "kind": "Class", "attrs": [["IdiomAnterior", "bool"]], "meths": [["Suscribir_43BO", "void", 1], ["Desuscribir_43BO", "void", 1], ["Notificar_43BO", "void", 2], ["ObtenerTexto_43BO", "string", 1], ["ObtenerTexto_43BO", "string", 2], ["CargarIdioma_43BO", "void", 1]]}, {"name": "Patente_43BO", "kind": "Class", "attrs": [], "meths": [["ObtenerPermisos_43BO", "string", 0]]}, {"name": "Familia_43BO", "kind": "Class", "attrs": [], "meths": [["ObtenerHijos_43BO", "Rol_43BO", 0], ["ObtenerTodosLosDescendientes_43BO", "Rol_43BO", 0], ["BuscarJerarquia_43BO", "bool", 1], ["Agregar_43BO", "void", 1], ["ObtenerPermisos_43BO", "string", 0], ["LimpiarHijos_43BO", "void", 0], ["AgregarHijo_43BO", "void", 1]]}, {"name": "Rol_43BO", "kind": "Class", "attrs": [["IdRol_43BO", "int"], ["Nombre_43BO", "string"]], "meths": []}];
var RELS = [["User_43BO", "Rol_43BO", "Association", "Rol"], ["Bitacora_43BO", "Evento_43BO", "Association", "Evento"], ["Bitacora_43BO", "Modulo_43BO", "Association", "Modulo"], ["Bitacora_43BO", "User_43BO", "Association", "log_43BO"], ["SessionManager_43BO", "User_43BO", "Association", "Usuario"], ["Patente_43BO", "Rol_43BO", "Generalization", ""], ["Familia_43BO", "Rol_43BO", "Generalization", ""]];

function log(s){ Session.Output("[DC] " + s); }

function main(){
    var pkg as EA.Package;
    pkg = Repository.GetTreeSelectedPackage();
    if (pkg == null){ Session.Prompt("Selecciona el paquete donde crear el diagrama.", promptOK); return; }
    try{
        var k;
        for (k=0;k<pkg.Diagrams.Count;k++){
            var dx as EA.Diagram; dx = pkg.Diagrams.GetAt(k);
            if (dx.Name == DIAG_NOMBRE){ pkg.Diagrams.DeleteAt(k,false); pkg.Diagrams.Refresh(); break; }
        }
        var dia as EA.Diagram;
        dia = pkg.Diagrams.AddNew(DIAG_NOMBRE, "Logical");
        dia.Update(); pkg.Diagrams.Refresh();

        var id = {};  // nombre -> ElementID
        var i,j;
        // 1) crear clases con atributos y metodos
        for (i=0;i<ELEMS.length;i++){
            var E = ELEMS[i];
            var e as EA.Element;
            e = pkg.Elements.AddNew(E.name, E.kind);
            e.Update();
            // atributos
            for (j=0;j<E.attrs.length;j++){
                var at as EA.Attribute;
                at = e.Attributes.AddNew(E.attrs[j][0], E.attrs[j][1]);
                at.Visibility = "Private";
                at.Update();
            }
            e.Attributes.Refresh();
            // metodos
            for (j=0;j<E.meths.length;j++){
                var mt as EA.Method;
                mt = e.Methods.AddNew(E.meths[j][0], E.meths[j][1]);
                mt.Visibility = "Public";
                mt.Update();
            }
            e.Methods.Refresh();
            id[E.name] = e.ElementID;
            pkg.Elements.Refresh();
        }
        // 2) ubicarlas en grilla (luego EA re-acomoda con auto-layout)
        var cols = Math.ceil(Math.sqrt(ELEMS.length));
        var cw = 220, ch = 170, x0 = 40, y0 = 40;
        for (i=0;i<ELEMS.length;i++){
            var cx = x0 + (i % cols) * cw;
            var cy = y0 + Math.floor(i / cols) * ch;
            var dobj as EA.DiagramObject;
            dobj = dia.DiagramObjects.AddNew("l=" + cx + ";r=" + (cx+180) + ";t=-" + cy + ";b=-" + (cy+120) + ";","");
            dobj.ElementID = id[ELEMS[i].name];
            dobj.Update();
        }
        dia.DiagramObjects.Refresh();
        // 3) relaciones
        for (i=0;i<RELS.length;i++){
            var R = RELS[i];              // [from,to,kind,label]
            if (id[R[0]]==null || id[R[1]]==null) continue;
            var src as EA.Element; src = Repository.GetElementByID(id[R[0]]);
            var con as EA.Connector;
            con = src.Connectors.AddNew(R[3]?R[3]:"", R[2]);
            con.SupplierID = id[R[1]];
            con.Update();
            src.Connectors.Refresh();
        }
        // 4) auto-layout + abrir
        Repository.ReloadDiagram(dia.DiagramID);
        var prj as EA.Project; prj = Repository.GetProjectInterface();
        try { prj.LayoutDiagramEx(dia.DiagramGUID, 4, 20, 20, 1, true); } catch(e1){ try{ prj.LayoutDiagram(dia.DiagramGUID, 0); }catch(e2){} }
        Repository.ReloadDiagram(dia.DiagramID);
        Repository.OpenDiagram(dia.DiagramID);
        log("LISTO: " + DIAG_NOMBRE + "  (" + ELEMS.length + " clases, " + RELS.length + " relaciones)");
    } catch(err){ Session.Output("ERROR: " + err.description); }
}
main();
