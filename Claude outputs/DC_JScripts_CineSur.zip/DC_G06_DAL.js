/*
 * Enterprise Architect - JScript : Diagrama de Clases
 *   G06 Diagrama de clases - DAL
 * ANTES DE EJECUTAR: cerra los diagramas abiertos en EA.
 * Re-ejecutable: si existe un diagrama con el mismo nombre en el paquete, lo borra y lo rehace.
 * USO: selecciona el paquete en el Browser -> Specialize > Scripting > New JScript Script ->
 *      pega todo -> Run Script. Al final hace auto-layout.
 */
!INC Local Scripts.EAConstants-JScript

var DIAG_NOMBRE = "G06 Diagrama de clases - DAL";
var ELEMS = [{"name": "DALVenta_14OR", "kind": "Class", "attrs": [], "meths": [["ConfirmarVenta_14OR", "int", 1]]}, {"name": "InstaladorBD_43BO", "kind": "Class", "attrs": [["CadenaActual", "string"]], "meths": [["ConnMaster", "string", 1], ["ExisteBaseDatos", "bool", 1], ["AsegurarBaseDatos", "void", 0], ["InstalarBaseDatos", "void", 1]]}, {"name": "DALBitacora_43BO", "kind": "Class", "attrs": [], "meths": [["GuardarLog_43BO", "void", 1], ["ListarBitacora_43BO", "DataTable", 5]]}, {"name": "AccesoBD_43BO", "kind": "Class", "attrs": [["ConnectionString", "string"]], "meths": [["ObtenerCadenaDeConfig_43BO", "string", 0], ["ObtenerCadenaConexion_43BO", "string", 0], ["Escribir_43BO", "int", 3], ["Leer_43BO", "DataTable", 3], ["EjecutarScalar_43BO", "int", 3]]}, {"name": "DALUser_43BO", "kind": "Class", "attrs": [], "meths": [["InsertarUser_43BO", "void", 1], ["ListarUsuarios_43BO", "User_43BO", 0], ["ModificarUser_43BO", "int", 3], ["EliminarUser_43BO", "int", 2], ["CambiarContraseña_43BO", "void", 2], ["BuscarUserName_43BO", "User_43BO", 1], ["BloquearUser_43BO", "int", 1], ["DesbloquearUser_43BO", "int", 2], ["CambiarIdiomaUsuario_43BO", "int", 2]]}, {"name": "DALpatente_43BO", "kind": "Class", "attrs": [], "meths": [["ObtenerPermisos_43BO", "int", 1], ["ObtenerPatentesRol_43BO", "Patente_43BO", 1], ["ObtenerFamiliasRol_43BO", "Familia_43BO", 1], ["ObtenerPatentesDeFamilia_43BO", "Patente_43BO", 1], ["ObtenerFamiliasHijas_43BO", "Familia_43BO", 1], ["ListarTodasLasPatentes_43BO", "Patente_43BO", 0], ["ListarTodasLasFamilias_43BO", "Familia_43BO", 0], ["ListarTodosLosRoles_43BO", "Familia_43BO", 0], ["RegistrarFamilia_43BO", "int", 1], ["RegistrarRol_43BO", "int", 1], ["AgregarComponenteHijo_43BO", "bool", 3], ["QuitarComponenteHijo_43BO", "bool", 3], ["EliminarRol_43BO", "void", 1], ["EliminarFamilia_43BO", "void", 1]]}, {"name": "DALdv_43BO", "kind": "Class", "attrs": [], "meths": [["CalcularDV_43BO", "DV_43BO", 0], ["ConvertirValorHex_43BO", "long", 1], ["GenerarYPersistirDV_43BO", "void", 0], ["RecalcularTrasPersistencia_43BO", "void", 0], ["ConsultarDV_43BO", "DV_43BO", 0], ["BackupBD_43BO", "void", 1], ["RestoreBD_43BO", "void", 1]]}, {"name": "DALProducto_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Producto_14OR", 0], ["ListarEnCritico_14OR", "Producto_14OR", 0], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["MapearProducto_14OR", "Producto_14OR", 1]]}, {"name": "DALVentaCandy_14OR", "kind": "Class", "attrs": [], "meths": [["ConfirmarVenta_14OR", "int", 1], ["Listar_14OR", "VentaCandy_14OR", 0]]}, {"name": "DALOrdenCompra_14OR", "kind": "Class", "attrs": [], "meths": [["GenerarDesdePresupuesto_14OR", "int", 1], ["Listar_14OR", "OrdenCompra_14OR", 0], ["ObtenerDetalle_14OR", "DetalleOrdenCompra_14OR", 1]]}, {"name": "DALProveedor_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Proveedor_14OR", 0], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["MapearProveedor_14OR", "Proveedor_14OR", 1]]}, {"name": "DALPresupuesto_14OR", "kind": "Class", "attrs": [], "meths": [["PedirPresupuesto_14OR", "int", 1], ["CargarCotizacion_14OR", "void", 1], ["CambiarEstado_14OR", "int", 2], ["Listar_14OR", "Presupuesto_14OR", 0], ["ObtenerDetalle_14OR", "DetallePresupuesto_14OR", 1]]}, {"name": "DALFuncion_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Funcion_14OR", 0], ["ListarPorSala_14OR", "Funcion_14OR", 1], ["ListarPorPelicula_14OR", "Funcion_14OR", 1], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["MapearLista_14OR", "Funcion_14OR", 1], ["FormatoATexto_14OR", "string", 1], ["TextoAFormato_14OR", "FormatoFuncion_14OR", 1]]}, {"name": "DALReporte_14OR", "kind": "Class", "attrs": [], "meths": [["ListadoFuncionesOcupacion_14OR", "ReporteFuncionOcupacion_14OR", 0]]}, {"name": "DALPromocion_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Promocion_14OR", 0], ["ListarPVigentes_14OR", "Promocion_14OR", 0], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["ArmarParametros_14OR", "SqlParameter", 1], ["MapearLista_14OR", "Promocion_14OR", 1], ["TipoATexto_14OR", "string", 1], ["TextoATipo_14OR", "TipoPromocion_14OR", 1]]}, {"name": "DALAsientoFuncion_14OR", "kind": "Class", "attrs": [], "meths": [["ContarAsientos_14OR", "int", 1], ["GenerarParaFuncion_14OR", "int", 2], ["EliminarPorFuncion_14OR", "int", 1], ["ObtenerMapa_14OR", "AsientoFuncion_14OR", 1], ["ContarLibres_14OR", "int", 1], ["ReservarSiLibres_14OR", "bool", 2], ["OcuparYAsociar_14OR", "int", 3], ["ObtenerAsiento_14OR", "AsientoFuncion_14OR", 2], ["RegistrarIngreso_14OR", "int", 2], ["LiberarReserva_14OR", "int", 2]]}, {"name": "DALSala_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Sala_14OR", 0], ["Alta_14OR", "int", 3], ["GenerarButacas_14OR", "void", 3], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1]]}, {"name": "DALButaca_14OR", "kind": "Class", "attrs": [], "meths": [["ListarPorSala_14OR", "Butaca_14OR", 1]]}, {"name": "DALPeliculaCambio_14OR", "kind": "Class", "attrs": [], "meths": [["Filtrar_14OR", "PeliculaCambio_14OR", 4], ["Rollback_14OR", "void", 1]]}, {"name": "DALPelicula_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Pelicula_14OR", 0], ["ListarEnCartelera_14OR", "Pelicula_14OR", 0], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1]]}, {"name": "DALCliente_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Cliente_14OR", 0], ["BuscarPorDni_14OR", "Cliente_14OR", 1], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["Suscribir_14OR", "int", 2], ["ArmarParametros_14OR", "SqlParameter", 1], ["MapearLista_14OR", "Cliente_14OR", 1]]}];
var RELS = [["DALVenta_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALUser_43BO", "AccesoBD_43BO", "Association", "acceso"], ["DALdv_43BO", "AccesoBD_43BO", "Association", "acceso"], ["DALProducto_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALVentaCandy_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALOrdenCompra_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALProveedor_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALPresupuesto_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALFuncion_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALReporte_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALPromocion_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALAsientoFuncion_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALSala_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALButaca_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALPeliculaCambio_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALPelicula_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALCliente_14OR", "AccesoBD_43BO", "Association", "acceso"]];

function log(s){ Session.Output("[DC] " + s); }

function main(){
    var pkg as EA.Package;
    pkg = Repository.GetTreeSelectedPackage();
    if (pkg == null){ Session.Prompt("Selecciona el paquete donde crear el diagrama.", promptOK); return; }
    try{
        var k;
        for (k=0;k<pkg.Diagrams.Count;k++){
            var dx as EA.Diagram; dx = pkg.Diagrams.GetAt(k);
            if (dx.Name == DIAG_NOMBRE){ pkg.Diagrams.DeleteAt(k,false); pkg.Diagrams.Refresh(); break; }
        }
        var dia as EA.Diagram;
        dia = pkg.Diagrams.AddNew(DIAG_NOMBRE, "Logical");
        dia.Update(); pkg.Diagrams.Refresh();

        var id = {};  // nombre -> ElementID
        var i,j;
        // 1) crear clases con atributos y metodos
        for (i=0;i<ELEMS.length;i++){
            var E = ELEMS[i];
            var e as EA.Element;
            e = pkg.Elements.AddNew(E.name, E.kind);
            e.Update();
            // atributos
            for (j=0;j<E.attrs.length;j++){
                var at as EA.Attribute;
                at = e.Attributes.AddNew(E.attrs[j][0], E.attrs[j][1]);
                at.Visibility = "Private";
                at.Update();
            }
            e.Attributes.Refresh();
            // metodos
            for (j=0;j<E.meths.length;j++){
                var mt as EA.Method;
                mt = e.Methods.AddNew(E.meths[j][0], E.meths[j][1]);
                mt.Visibility = "Public";
                mt.Update();
            }
            e.Methods.Refresh();
            id[E.name] = e.ElementID;
            pkg.Elements.Refresh();
        }
        // 2) ubicarlas en grilla (luego EA re-acomoda con auto-layout)
        var cols = Math.ceil(Math.sqrt(ELEMS.length));
        var cw = 220, ch = 170, x0 = 40, y0 = 40;
        for (i=0;i<ELEMS.length;i++){
            var cx = x0 + (i % cols) * cw;
            var cy = y0 + Math.floor(i / cols) * ch;
            var dobj as EA.DiagramObject;
            dobj = dia.DiagramObjects.AddNew("l=" + cx + ";r=" + (cx+180) + ";t=-" + cy + ";b=-" + (cy+120) + ";","");
            dobj.ElementID = id[ELEMS[i].name];
            dobj.Update();
        }
        dia.DiagramObjects.Refresh();
        // 3) relaciones
        for (i=0;i<RELS.length;i++){
            var R = RELS[i];              // [from,to,kind,label]
            if (id[R[0]]==null || id[R[1]]==null) continue;
            var src as EA.Element; src = Repository.GetElementByID(id[R[0]]);
            var con as EA.Connector;
            con = src.Connectors.AddNew(R[3]?R[3]:"", R[2]);
            con.SupplierID = id[R[1]];
            con.Update();
            src.Connectors.Refresh();
        }
        // 4) auto-layout + abrir
        Repository.ReloadDiagram(dia.DiagramID);
        var prj as EA.Project; prj = Repository.GetProjectInterface();
        try { prj.LayoutDiagramEx(dia.DiagramGUID, 4, 20, 20, 1, true); } catch(e1){ try{ prj.LayoutDiagram(dia.DiagramGUID, 0); }catch(e2){} }
        Repository.ReloadDiagram(dia.DiagramID);
        Repository.OpenDiagram(dia.DiagramID);
        log("LISTO: " + DIAG_NOMBRE + "  (" + ELEMS.length + " clases, " + RELS.length + " relaciones)");
    } catch(err){ Session.Output("ERROR: " + err.description); }
}
main();
