/*
 * Enterprise Architect - JScript : Diagrama de Clases
 *   Diagrama de Clases CUN-005 Registrar solicitud de cotizacion
 * ANTES DE EJECUTAR: cerra los diagramas abiertos en EA.
 * Re-ejecutable: si existe un diagrama con el mismo nombre en el paquete, lo borra y lo rehace.
 * USO: selecciona el paquete en el Browser -> Specialize > Scripting > New JScript Script ->
 *      pega todo -> Run Script. Al final hace auto-layout.
 */
!INC Local Scripts.EAConstants-JScript

var DIAG_NOMBRE = "Diagrama de Clases CUN-005 Registrar solicitud de cotizacion";
var ELEMS = [{"name": "BllProducto_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Producto_14OR", 0], ["ListarEnCritico_14OR", "Producto_14OR", 0], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["ValidarProducto_14OR", "void", 1]]}, {"name": "BllProveedor_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Proveedor_14OR", 0], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["ValidarProveedor_14OR", "void", 1]]}, {"name": "BllPresupuesto_14OR", "kind": "Class", "attrs": [], "meths": [["PedirPresupuesto_14OR", "int", 2], ["CargarCotizacion_14OR", "void", 1], ["Rechazar_14OR", "void", 1], ["Listar_14OR", "Presupuesto_14OR", 0], ["ObtenerDetalle_14OR", "DetallePresupuesto_14OR", 1]]}, {"name": "DALProducto_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Producto_14OR", 0], ["ListarEnCritico_14OR", "Producto_14OR", 0], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["MapearProducto_14OR", "Producto_14OR", 1]]}, {"name": "DALProveedor_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Proveedor_14OR", 0], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["MapearProveedor_14OR", "Proveedor_14OR", 1]]}, {"name": "DALPresupuesto_14OR", "kind": "Class", "attrs": [], "meths": [["PedirPresupuesto_14OR", "int", 1], ["CargarCotizacion_14OR", "void", 1], ["CambiarEstado_14OR", "int", 2], ["Listar_14OR", "Presupuesto_14OR", 0], ["ObtenerDetalle_14OR", "DetallePresupuesto_14OR", 1]]}, {"name": "Producto_14OR", "kind": "Class", "attrs": [["IdProducto_14OR", "int"], ["Nombre_14OR", "string"], ["PrecioVenta_14OR", "double"], ["Stock_14OR", "int"], ["StockCritico_14OR", "int"], ["Activo_14OR", "bool"], ["Imagen_14OR", "string"], ["PrecioCosto_14OR", "double"]], "meths": []}, {"name": "Proveedor_14OR", "kind": "Class", "attrs": [["IdProveedor_14OR", "int"], ["Nombre_14OR", "string"], ["Telefono_14OR", "string"], ["Email_14OR", "string"], ["Activo_14OR", "bool"]], "meths": []}, {"name": "Presupuesto_14OR", "kind": "Class", "attrs": [["IdPresupuesto_14OR", "int"], ["NumeroPresupuesto_14OR", "int"], ["IdProveedor_14OR", "int"], ["NombreProveedor_14OR", "string"], ["FechaPedido_14OR", "DateTime"], ["Estado_14OR", "string"], ["Detalles", "DetallePresupuesto_14OR"]], "meths": []}, {"name": "DetallePresupuesto_14OR", "kind": "Class", "attrs": [["IdDetallePresupuesto_14OR", "int"], ["IdPresupuesto_14OR", "int"], ["IdProducto_14OR", "int"], ["NombreProducto_14OR", "string"], ["Cantidad_14OR", "int"], ["PrecioCotizado_14OR", "double"], ["Subtotal_14OR", "double"]], "meths": []}, {"name": "AccesoBD_43BO", "kind": "Class", "attrs": [["ConnectionString", "string"]], "meths": [["ObtenerCadenaDeConfig_43BO", "string", 0], ["ObtenerCadenaConexion_43BO", "string", 0], ["Escribir_43BO", "int", 3], ["Leer_43BO", "DataTable", 3], ["EjecutarScalar_43BO", "int", 3]]}, {"name": "BLLBitacora_43BO", "kind": "Class", "attrs": [], "meths": [["GuardarLog_43BO", "void", 4], ["ListarBitacora_43BO", "DataTable", 5], ["Imprimir_43BO", "void", 4]]}, {"name": "BllDV_43BO", "kind": "Class", "attrs": [], "meths": [["ObtenerRutaBackups_43BO", "string", 0], ["GuardarRutaBackups_43BO", "void", 1], ["GenerarDV_43BO", "void", 1], ["VerificarDV_43BO", "bool", 1], ["GenerarBackup_43BO", "string", 2], ["ListarBackups_43BO", "string", 0], ["RestaurarBackup_43BO", "void", 2]]}];
var RELS = [["BllProducto_14OR", "DALProducto_14OR", "Association", "dal"], ["BllProducto_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["BllProveedor_14OR", "DALProveedor_14OR", "Association", "dal"], ["BllProveedor_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["BllPresupuesto_14OR", "DALPresupuesto_14OR", "Association", "dal"], ["BllPresupuesto_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["DALProducto_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALProveedor_14OR", "AccesoBD_43BO", "Association", "acceso"], ["DALPresupuesto_14OR", "AccesoBD_43BO", "Association", "acceso"], ["Presupuesto_14OR", "DetallePresupuesto_14OR", "Aggregation", "Detalles"], ["BllProducto_14OR", "BllDV_43BO", "Association", "dv"], ["BllProveedor_14OR", "BllDV_43BO", "Association", "dv"], ["BllPresupuesto_14OR", "BllDV_43BO", "Association", "dv"]];

function log(s){ Session.Output("[DC] " + s); }

function main(){
    var pkg as EA.Package;
    pkg = Repository.GetTreeSelectedPackage();
    if (pkg == null){ Session.Prompt("Selecciona el paquete donde crear el diagrama.", promptOK); return; }
    try{
        var k;
        for (k=0;k<pkg.Diagrams.Count;k++){
            var dx as EA.Diagram; dx = pkg.Diagrams.GetAt(k);
            if (dx.Name == DIAG_NOMBRE){ pkg.Diagrams.DeleteAt(k,false); pkg.Diagrams.Refresh(); break; }
        }
        var dia as EA.Diagram;
        dia = pkg.Diagrams.AddNew(DIAG_NOMBRE, "Logical");
        dia.Update(); pkg.Diagrams.Refresh();

        var id = {};  // nombre -> ElementID
        var i,j;
        // 1) crear clases con atributos y metodos
        for (i=0;i<ELEMS.length;i++){
            var E = ELEMS[i];
            var e as EA.Element;
            e = pkg.Elements.AddNew(E.name, E.kind);
            e.Update();
            // atributos
            for (j=0;j<E.attrs.length;j++){
                var at as EA.Attribute;
                at = e.Attributes.AddNew(E.attrs[j][0], E.attrs[j][1]);
                at.Visibility = "Private";
                at.Update();
            }
            e.Attributes.Refresh();
            // metodos
            for (j=0;j<E.meths.length;j++){
                var mt as EA.Method;
                mt = e.Methods.AddNew(E.meths[j][0], E.meths[j][1]);
                mt.Visibility = "Public";
                mt.Update();
            }
            e.Methods.Refresh();
            id[E.name] = e.ElementID;
            pkg.Elements.Refresh();
        }
        // 2) ubicarlas en grilla (luego EA re-acomoda con auto-layout)
        var cols = Math.ceil(Math.sqrt(ELEMS.length));
        var cw = 220, ch = 170, x0 = 40, y0 = 40;
        for (i=0;i<ELEMS.length;i++){
            var cx = x0 + (i % cols) * cw;
            var cy = y0 + Math.floor(i / cols) * ch;
            var dobj as EA.DiagramObject;
            dobj = dia.DiagramObjects.AddNew("l=" + cx + ";r=" + (cx+180) + ";t=-" + cy + ";b=-" + (cy+120) + ";","");
            dobj.ElementID = id[ELEMS[i].name];
            dobj.Update();
        }
        dia.DiagramObjects.Refresh();
        // 3) relaciones
        for (i=0;i<RELS.length;i++){
            var R = RELS[i];              // [from,to,kind,label]
            if (id[R[0]]==null || id[R[1]]==null) continue;
            var src as EA.Element; src = Repository.GetElementByID(id[R[0]]);
            var con as EA.Connector;
            con = src.Connectors.AddNew(R[3]?R[3]:"", R[2]);
            con.SupplierID = id[R[1]];
            con.Update();
            src.Connectors.Refresh();
        }
        // 4) auto-layout + abrir
        Repository.ReloadDiagram(dia.DiagramID);
        var prj as EA.Project; prj = Repository.GetProjectInterface();
        try { prj.LayoutDiagramEx(dia.DiagramGUID, 4, 20, 20, 1, true); } catch(e1){ try{ prj.LayoutDiagram(dia.DiagramGUID, 0); }catch(e2){} }
        Repository.ReloadDiagram(dia.DiagramID);
        Repository.OpenDiagram(dia.DiagramID);
        log("LISTO: " + DIAG_NOMBRE + "  (" + ELEMS.length + " clases, " + RELS.length + " relaciones)");
    } catch(err){ Session.Output("ERROR: " + err.description); }
}
main();
