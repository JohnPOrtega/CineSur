/*
 * Enterprise Architect - JScript : Diagrama de Clases
 *   G06 Diagrama de clases - BLL
 * ANTES DE EJECUTAR: cerra los diagramas abiertos en EA.
 * Re-ejecutable: si existe un diagrama con el mismo nombre en el paquete, lo borra y lo rehace.
 * USO: selecciona el paquete en el Browser -> Specialize > Scripting > New JScript Script ->
 *      pega todo -> Run Script. Al final hace auto-layout.
 */
!INC Local Scripts.EAConstants-JScript

var DIAG_NOMBRE = "G06 Diagrama de clases - BLL";
var ELEMS = [{"name": "BLLBitacora_43BO", "kind": "Class", "attrs": [], "meths": [["GuardarLog_43BO", "void", 4], ["ListarBitacora_43BO", "DataTable", 5], ["Imprimir_43BO", "void", 4]]}, {"name": "BLLpatente_43BO", "kind": "Class", "attrs": [], "meths": [["RegistrarFamilia_43BO", "int", 1], ["RegistrarRol_43BO", "int", 1], ["ListarTodasLasPatentes_43BO", "Patente_43BO", 0], ["ListarTodasLasFamilias_43BO", "Familia_43BO", 0], ["ListarTodosLosRoles_43BO", "Familia_43BO", 0], ["AgregarComponenteHijo_43BO", "bool", 3], ["QuitarComponenteHijo_43BO", "bool", 3], ["HidratarRolCompleto_43BO", "void", 1], ["HidratarFamiliaRecursivo_43BO", "void", 2], ["EliminarRol_43BO", "void", 1], ["EliminarFamilia_43BO", "void", 1], ["ModificarNombreComponente_43BO", "bool", 3], ["ObtenerPermisosDeRol_43BO", "string", 1], ["ObtenerTodosLosIdsPatentes_43BO", "void", 2]]}, {"name": "BllPeliculaCambio_14OR", "kind": "Class", "attrs": [], "meths": [["Filtrar_14OR", "PeliculaCambio_14OR", 4], ["Rollback_14OR", "void", 1]]}, {"name": "BllDV_43BO", "kind": "Class", "attrs": [], "meths": [["ObtenerRutaBackups_43BO", "string", 0], ["GuardarRutaBackups_43BO", "void", 1], ["GenerarDV_43BO", "void", 1], ["VerificarDV_43BO", "bool", 1], ["GenerarBackup_43BO", "string", 2], ["ListarBackups_43BO", "string", 0], ["RestaurarBackup_43BO", "void", 2]]}, {"name": "BllUser_43BO", "kind": "Class", "attrs": [], "meths": [["CambiarContraseña_43BO", "void", 4], ["VerificarCredenciales_43BO", "User_43BO", 2], ["CompletarLogin_43BO", "void", 1], ["ValidarLogin_43BO", "bool", 2], ["EsAdmin_43BO", "bool", 1], ["ManejarFallos_43BO", "void", 2], ["ReiniciarIn_43BO", "void", 1], ["CerrarSesion_43BO", "void", 0], ["InsertarUser_43BO", "void", 5], ["ModificarUser_43BO", "int", 3], ["Eliminar_43BO", "void", 2], ["DesbloquearUser_43BO", "void", 1], ["EsContraseñaDeFabrica_43BO", "bool", 1], ["ObtenerPermisosDeRol_43BO", "string", 1]]}, {"name": "BLLInstalador_43BO", "kind": "Class", "attrs": [["NombreBD", "string"], ["CadenaActual", "string"]], "meths": [["AsegurarBaseDatos", "void", 0]]}, {"name": "ResultadoReserva_14OR", "kind": "Class", "attrs": [], "meths": []}, {"name": "BllVenta_14OR", "kind": "Class", "attrs": [], "meths": [["ReservarButacas_14OR", "ResultadoReserva_14OR", 2], ["ConfirmarVenta_14OR", "int", 7], ["LiberarReserva_14OR", "void", 2], ["ValidarTarjeta_14OR", "void", 3], ["LuhnValido_14OR", "bool", 1], ["VencimientoValido_14OR", "bool", 1]]}, {"name": "BllPelicula_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Pelicula_14OR", 0], ["ListarEnCartelera_14OR", "Pelicula_14OR", 0], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["ValidarPelicula_14OR", "void", 1]]}, {"name": "ResultadoIngreso_14OR", "kind": "Class", "attrs": [], "meths": []}, {"name": "BllAsientoFuncion_14OR", "kind": "Class", "attrs": [], "meths": [["ObtenerMapa_14OR", "AsientoFuncion_14OR", 2], ["ContarLibres_14OR", "int", 1], ["LibresParaMostrar_14OR", "int", 2], ["RegistrarIngreso_14OR", "ResultadoIngreso_14OR", 2]]}, {"name": "BllFuncion_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Funcion_14OR", 0], ["ListarPorPelicula_14OR", "Funcion_14OR", 1], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["ValidarFuncion_14OR", "void", 1], ["CalcularPrecioFinal_14OR", "double", 1], ["ValidarMantenimiento_14OR", "void", 2]]}, {"name": "BllPromocion_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Promocion_14OR", 0], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["Validar_14OR", "void", 1], ["ListarPVigentes_14OR", "Promocion_14OR", 0], ["CalcularDescuento_14OR", "double", 4]]}, {"name": "BllReporte_14OR", "kind": "Class", "attrs": [], "meths": [["ListadoFuncionesOcupacion_14OR", "ReporteFuncionOcupacion_14OR", 0]]}, {"name": "BllSala_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Sala_14OR", 0], ["Alta_14OR", "int", 3], ["Modificar_14OR", "int", 1], ["ExisteNumero_14OR", "bool", 2], ["Baja_14OR", "int", 1]]}, {"name": "BllCliente_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Cliente_14OR", 0], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["BuscarPorDni_14OR", "Cliente_14OR", 1], ["BuscarPorDniParaNegocio_14OR", "Cliente_14OR", 1], ["Suscribir_14OR", "void", 1], ["AltaSocioRapido_14OR", "Cliente_14OR", 1], ["PrepararClienteParaGuardar_14OR", "Cliente_14OR", 1], ["DesencriptarCliente_14OR", "Cliente_14OR", 1], ["DesencriptarLista_14OR", "Cliente_14OR", 1], ["Validar_14OR", "void", 1], ["SerializarXml_14OR", "void", 2], ["DeserializarXml_14OR", "Cliente_14OR", 1]]}, {"name": "BllPresupuesto_14OR", "kind": "Class", "attrs": [], "meths": [["PedirPresupuesto_14OR", "int", 2], ["CargarCotizacion_14OR", "void", 1], ["Rechazar_14OR", "void", 1], ["Listar_14OR", "Presupuesto_14OR", 0], ["ObtenerDetalle_14OR", "DetallePresupuesto_14OR", 1]]}, {"name": "BllVentaCandy_14OR", "kind": "Class", "attrs": [], "meths": [["ConfirmarVenta_14OR", "int", 3], ["Listar_14OR", "VentaCandy_14OR", 0]]}, {"name": "BllOrdenCompra_14OR", "kind": "Class", "attrs": [], "meths": [["GenerarDesdePresupuesto_14OR", "int", 1], ["Listar_14OR", "OrdenCompra_14OR", 0], ["ObtenerDetalle_14OR", "DetalleOrdenCompra_14OR", 1]]}, {"name": "BllProducto_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Producto_14OR", 0], ["ListarEnCritico_14OR", "Producto_14OR", 0], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["ValidarProducto_14OR", "void", 1]]}, {"name": "BllProveedor_14OR", "kind": "Class", "attrs": [], "meths": [["Listar_14OR", "Proveedor_14OR", 0], ["Alta_14OR", "int", 1], ["Modificar_14OR", "int", 1], ["Baja_14OR", "int", 1], ["ValidarProveedor_14OR", "void", 1]]}];
var RELS = [["BllPeliculaCambio_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["BllUser_43BO", "BLLBitacora_43BO", "Association", "bllBi"], ["BllUser_43BO", "BLLpatente_43BO", "Association", "bllPatente"], ["BllVenta_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["BllPelicula_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["BllAsientoFuncion_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["BllFuncion_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["BllPromocion_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["BllSala_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["BllCliente_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["BllPresupuesto_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["BllVentaCandy_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["BllOrdenCompra_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["BllProducto_14OR", "BLLBitacora_43BO", "Association", "bllBi"], ["BllProveedor_14OR", "BLLBitacora_43BO", "Association", "bllBi"]];

function log(s){ Session.Output("[DC] " + s); }

function main(){
    var pkg as EA.Package;
    pkg = Repository.GetTreeSelectedPackage();
    if (pkg == null){ Session.Prompt("Selecciona el paquete donde crear el diagrama.", promptOK); return; }
    try{
        var k;
        for (k=0;k<pkg.Diagrams.Count;k++){
            var dx as EA.Diagram; dx = pkg.Diagrams.GetAt(k);
            if (dx.Name == DIAG_NOMBRE){ pkg.Diagrams.DeleteAt(k,false); pkg.Diagrams.Refresh(); break; }
        }
        var dia as EA.Diagram;
        dia = pkg.Diagrams.AddNew(DIAG_NOMBRE, "Logical");
        dia.Update(); pkg.Diagrams.Refresh();

        var id = {};  // nombre -> ElementID
        var i,j;
        // 1) crear clases con atributos y metodos
        for (i=0;i<ELEMS.length;i++){
            var E = ELEMS[i];
            var e as EA.Element;
            e = pkg.Elements.AddNew(E.name, E.kind);
            e.Update();
            // atributos
            for (j=0;j<E.attrs.length;j++){
                var at as EA.Attribute;
                at = e.Attributes.AddNew(E.attrs[j][0], E.attrs[j][1]);
                at.Visibility = "Private";
                at.Update();
            }
            e.Attributes.Refresh();
            // metodos
            for (j=0;j<E.meths.length;j++){
                var mt as EA.Method;
                mt = e.Methods.AddNew(E.meths[j][0], E.meths[j][1]);
                mt.Visibility = "Public";
                mt.Update();
            }
            e.Methods.Refresh();
            id[E.name] = e.ElementID;
            pkg.Elements.Refresh();
        }
        // 2) ubicarlas en grilla (luego EA re-acomoda con auto-layout)
        var cols = Math.ceil(Math.sqrt(ELEMS.length));
        var cw = 220, ch = 170, x0 = 40, y0 = 40;
        for (i=0;i<ELEMS.length;i++){
            var cx = x0 + (i % cols) * cw;
            var cy = y0 + Math.floor(i / cols) * ch;
            var dobj as EA.DiagramObject;
            dobj = dia.DiagramObjects.AddNew("l=" + cx + ";r=" + (cx+180) + ";t=-" + cy + ";b=-" + (cy+120) + ";","");
            dobj.ElementID = id[ELEMS[i].name];
            dobj.Update();
        }
        dia.DiagramObjects.Refresh();
        // 3) relaciones
        for (i=0;i<RELS.length;i++){
            var R = RELS[i];              // [from,to,kind,label]
            if (id[R[0]]==null || id[R[1]]==null) continue;
            var src as EA.Element; src = Repository.GetElementByID(id[R[0]]);
            var con as EA.Connector;
            con = src.Connectors.AddNew(R[3]?R[3]:"", R[2]);
            con.SupplierID = id[R[1]];
            con.Update();
            src.Connectors.Refresh();
        }
        // 4) auto-layout + abrir
        Repository.ReloadDiagram(dia.DiagramID);
        var prj as EA.Project; prj = Repository.GetProjectInterface();
        try { prj.LayoutDiagramEx(dia.DiagramGUID, 4, 20, 20, 1, true); } catch(e1){ try{ prj.LayoutDiagram(dia.DiagramGUID, 0); }catch(e2){} }
        Repository.ReloadDiagram(dia.DiagramID);
        Repository.OpenDiagram(dia.DiagramID);
        log("LISTO: " + DIAG_NOMBRE + "  (" + ELEMS.length + " clases, " + RELS.length + " relaciones)");
    } catch(err){ Session.Output("ERROR: " + err.description); }
}
main();
