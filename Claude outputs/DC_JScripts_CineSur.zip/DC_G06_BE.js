/*
 * Enterprise Architect - JScript : Diagrama de Clases
 *   G06 Diagrama de clases - BE (Entidades)
 * ANTES DE EJECUTAR: cerra los diagramas abiertos en EA.
 * Re-ejecutable: si existe un diagrama con el mismo nombre en el paquete, lo borra y lo rehace.
 * USO: selecciona el paquete en el Browser -> Specialize > Scripting > New JScript Script ->
 *      pega todo -> Run Script. Al final hace auto-layout.
 */
!INC Local Scripts.EAConstants-JScript

var DIAG_NOMBRE = "G06 Diagrama de clases - BE (Entidades)";
var ELEMS = [{"name": "BllButaca_14OR", "kind": "Class", "attrs": [["dal", "DALButaca_14OR"]], "meths": [["ListarPorSala_14OR", "Butaca_14OR", 1]]}, {"name": "Venta_14OR", "kind": "Class", "attrs": [["IdVenta_14OR", "int"], ["NumeroVenta_14OR", "int"], ["Fecha_14OR", "DateTime"], ["Hora_14OR", "DateTime"], ["Estado_14OR", "string"], ["MetodoPago_14OR", "string"], ["MontoTotal_14OR", "double"], ["MontoDescuento_14OR", "double"], ["Cliente", "Cliente_14OR"], ["Promocion", "Promocion_14OR"], ["Asientos", "AsientoFuncion_14OR"]], "meths": []}, {"name": "Producto_14OR", "kind": "Class", "attrs": [["IdProducto_14OR", "int"], ["Nombre_14OR", "string"], ["PrecioVenta_14OR", "double"], ["Stock_14OR", "int"], ["StockCritico_14OR", "int"], ["Activo_14OR", "bool"], ["Imagen_14OR", "string"], ["PrecioCosto_14OR", "double"]], "meths": []}, {"name": "ClientesXml_14OR", "kind": "Class", "attrs": [["Clientes_14OR", "Cliente_14OR"]], "meths": []}, {"name": "FormatoFuncion_14OR", "kind": "Class", "attrs": [], "meths": []}, {"name": "Cliente_14OR", "kind": "Class", "attrs": [["IdCliente_14OR", "int"], ["Nombre_14OR", "string"], ["Apellido_14OR", "string"], ["DNI_14OR", "int"], ["Email_14OR", "string"], ["Telefono_14OR", "string"], ["Suscriptor_14OR", "bool"], ["Eliminado_14OR", "bool"]], "meths": []}, {"name": "Pelicula_14OR", "kind": "Class", "attrs": [["IdPelicula_14OR", "int"], ["Titulo_14OR", "string"], ["Genero_14OR", "string"], ["Duracion_14OR", "int"], ["Poster_14OR", "string"]], "meths": []}, {"name": "PeliculaCambio_14OR", "kind": "Class", "attrs": [["IdCambio_14OR", "int"], ["IdPelicula_14OR", "int"], ["Titulo_14OR", "string"], ["Genero_14OR", "string"], ["Duracion_14OR", "int"], ["Poster_14OR", "string"], ["Act_14OR", "bool"], ["TipoCambio_14OR", "string"], ["FechaHora_14OR", "DateTime"]], "meths": []}, {"name": "Funcion_14OR", "kind": "Class", "attrs": [["IdFuncion_14OR", "int"], ["Fecha_14OR", "DateTime"], ["Horario_14OR", "DateTime"], ["Formato_14OR", "FormatoFuncion_14OR"], ["Idioma_14OR", "string"], ["Precio_14OR", "double"], ["Pelicula", "Pelicula_14OR"], ["Sala", "Sala_14OR"], ["Asientos", "AsientoFuncion_14OR"]], "meths": []}, {"name": "Sala_14OR", "kind": "Class", "attrs": [["IdSala_14OR", "int"], ["Numero_14OR", "int"], ["Capacidad_14OR", "int"], ["Pasillos_14OR", "string"], ["Butacas", "Butaca_14OR"]], "meths": []}, {"name": "TipoPromocion_14OR", "kind": "Class", "attrs": [], "meths": []}, {"name": "Promocion_14OR", "kind": "Class", "attrs": [["IdPromocion_14OR", "int"], ["Nombre_14OR", "string"], ["Tipo_14OR", "TipoPromocion_14OR"], ["Valor_14OR", "double"], ["FechaInicio_14OR", "DateTime"], ["FechaFin_14OR", "DateTime"], ["Activa_14OR", "bool"]], "meths": []}, {"name": "AsientoFuncion_14OR", "kind": "Class", "attrs": [["Estado_14OR", "string"], ["Ingreso_14OR", "bool"], ["Funcion", "Funcion_14OR"], ["Butaca", "Butaca_14OR"]], "meths": []}, {"name": "ReporteFuncionOcupacion_14OR", "kind": "Class", "attrs": [["IdFuncion_14OR", "int"], ["Pelicula_14OR", "string"], ["Sala_14OR", "int"], ["Fecha_14OR", "DateTime"], ["Horario_14OR", "DateTime"], ["TicketsVendidos_14OR", "int"], ["ButacasDisponibles_14OR", "int"], ["RecaudacionParcial_14OR", "double"]], "meths": []}, {"name": "Butaca_14OR", "kind": "Class", "attrs": [["IdButaca_14OR", "int"], ["NumeroFila_14OR", "int"], ["NumeroAsiento_14OR", "int"]], "meths": []}, {"name": "DetallePresupuesto_14OR", "kind": "Class", "attrs": [["IdDetallePresupuesto_14OR", "int"], ["IdPresupuesto_14OR", "int"], ["IdProducto_14OR", "int"], ["NombreProducto_14OR", "string"], ["Cantidad_14OR", "int"], ["PrecioCotizado_14OR", "double"], ["Subtotal_14OR", "double"]], "meths": []}, {"name": "OrdenCompra_14OR", "kind": "Class", "attrs": [["IdOrdenCompra_14OR", "int"], ["NumeroOrden_14OR", "int"], ["IdProveedor_14OR", "int"], ["NombreProveedor_14OR", "string"], ["IdPresupuesto_14OR", "int"], ["FechaEmision_14OR", "DateTime"], ["Estado_14OR", "string"], ["Importe_14OR", "double"], ["FechaPago_14OR", "DateTime"], ["NumeroRemito_14OR", "string"], ["FechaRecepcion_14OR", "DateTime"], ["Detalles", "DetalleOrdenCompra_14OR"]], "meths": []}, {"name": "Presupuesto_14OR", "kind": "Class", "attrs": [["IdPresupuesto_14OR", "int"], ["NumeroPresupuesto_14OR", "int"], ["IdProveedor_14OR", "int"], ["NombreProveedor_14OR", "string"], ["FechaPedido_14OR", "DateTime"], ["Estado_14OR", "string"], ["Detalles", "DetallePresupuesto_14OR"]], "meths": []}, {"name": "Proveedor_14OR", "kind": "Class", "attrs": [["IdProveedor_14OR", "int"], ["Nombre_14OR", "string"], ["Telefono_14OR", "string"], ["Email_14OR", "string"], ["Activo_14OR", "bool"]], "meths": []}, {"name": "DetalleVentaCandy_14OR", "kind": "Class", "attrs": [["IdDetalleVentaCandy_14OR", "int"], ["IdVentaCandy_14OR", "int"], ["IdProducto_14OR", "int"], ["NombreProducto_14OR", "string"], ["Cantidad_14OR", "int"], ["PrecioUnitario_14OR", "double"], ["Subtotal_14OR", "double"]], "meths": []}, {"name": "VentaCandy_14OR", "kind": "Class", "attrs": [["IdVentaCandy_14OR", "int"], ["NumeroVenta_14OR", "int"], ["Fecha_14OR", "DateTime"], ["Hora_14OR", "DateTime"], ["MetodoPago_14OR", "string"], ["MontoTotal_14OR", "double"], ["Detalles", "DetalleVentaCandy_14OR"]], "meths": []}, {"name": "DetalleOrdenCompra_14OR", "kind": "Class", "attrs": [["IdDetalleOrdenCompra_14OR", "int"], ["IdOrdenCompra_14OR", "int"], ["IdProducto_14OR", "int"], ["NombreProducto_14OR", "string"], ["Cantidad_14OR", "int"], ["PrecioCosto_14OR", "double"], ["Subtotal_14OR", "double"]], "meths": []}];
var RELS = [["Venta_14OR", "Cliente_14OR", "Association", "Cliente"], ["Venta_14OR", "Promocion_14OR", "Association", "Promocion"], ["Venta_14OR", "AsientoFuncion_14OR", "Aggregation", "Asientos"], ["ClientesXml_14OR", "Cliente_14OR", "Aggregation", "Clientes_14OR"], ["Funcion_14OR", "FormatoFuncion_14OR", "Association", "Formato_14OR"], ["Funcion_14OR", "Pelicula_14OR", "Association", "Pelicula"], ["Funcion_14OR", "Sala_14OR", "Association", "Sala"], ["Funcion_14OR", "AsientoFuncion_14OR", "Aggregation", "Asientos"], ["Sala_14OR", "Butaca_14OR", "Aggregation", "Butacas"], ["Promocion_14OR", "TipoPromocion_14OR", "Association", "Tipo_14OR"], ["AsientoFuncion_14OR", "Funcion_14OR", "Association", "Funcion"], ["AsientoFuncion_14OR", "Butaca_14OR", "Association", "Butaca"], ["OrdenCompra_14OR", "DetalleOrdenCompra_14OR", "Aggregation", "Detalles"], ["Presupuesto_14OR", "DetallePresupuesto_14OR", "Aggregation", "Detalles"], ["VentaCandy_14OR", "DetalleVentaCandy_14OR", "Aggregation", "Detalles"]];

function log(s){ Session.Output("[DC] " + s); }

function main(){
    var pkg as EA.Package;
    pkg = Repository.GetTreeSelectedPackage();
    if (pkg == null){ Session.Prompt("Selecciona el paquete donde crear el diagrama.", promptOK); return; }
    try{
        var k;
        for (k=0;k<pkg.Diagrams.Count;k++){
            var dx as EA.Diagram; dx = pkg.Diagrams.GetAt(k);
            if (dx.Name == DIAG_NOMBRE){ pkg.Diagrams.DeleteAt(k,false); pkg.Diagrams.Refresh(); break; }
        }
        var dia as EA.Diagram;
        dia = pkg.Diagrams.AddNew(DIAG_NOMBRE, "Logical");
        dia.Update(); pkg.Diagrams.Refresh();

        var id = {};  // nombre -> ElementID
        var i,j;
        // 1) crear clases con atributos y metodos
        for (i=0;i<ELEMS.length;i++){
            var E = ELEMS[i];
            var e as EA.Element;
            e = pkg.Elements.AddNew(E.name, E.kind);
            e.Update();
            // atributos
            for (j=0;j<E.attrs.length;j++){
                var at as EA.Attribute;
                at = e.Attributes.AddNew(E.attrs[j][0], E.attrs[j][1]);
                at.Visibility = "Private";
                at.Update();
            }
            e.Attributes.Refresh();
            // metodos
            for (j=0;j<E.meths.length;j++){
                var mt as EA.Method;
                mt = e.Methods.AddNew(E.meths[j][0], E.meths[j][1]);
                mt.Visibility = "Public";
                mt.Update();
            }
            e.Methods.Refresh();
            id[E.name] = e.ElementID;
            pkg.Elements.Refresh();
        }
        // 2) ubicarlas en grilla (luego EA re-acomoda con auto-layout)
        var cols = Math.ceil(Math.sqrt(ELEMS.length));
        var cw = 220, ch = 170, x0 = 40, y0 = 40;
        for (i=0;i<ELEMS.length;i++){
            var cx = x0 + (i % cols) * cw;
            var cy = y0 + Math.floor(i / cols) * ch;
            var dobj as EA.DiagramObject;
            dobj = dia.DiagramObjects.AddNew("l=" + cx + ";r=" + (cx+180) + ";t=-" + cy + ";b=-" + (cy+120) + ";","");
            dobj.ElementID = id[ELEMS[i].name];
            dobj.Update();
        }
        dia.DiagramObjects.Refresh();
        // 3) relaciones
        for (i=0;i<RELS.length;i++){
            var R = RELS[i];              // [from,to,kind,label]
            if (id[R[0]]==null || id[R[1]]==null) continue;
            var src as EA.Element; src = Repository.GetElementByID(id[R[0]]);
            var con as EA.Connector;
            con = src.Connectors.AddNew(R[3]?R[3]:"", R[2]);
            con.SupplierID = id[R[1]];
            con.Update();
            src.Connectors.Refresh();
        }
        // 4) auto-layout + abrir
        Repository.ReloadDiagram(dia.DiagramID);
        var prj as EA.Project; prj = Repository.GetProjectInterface();
        try { prj.LayoutDiagramEx(dia.DiagramGUID, 4, 20, 20, 1, true); } catch(e1){ try{ prj.LayoutDiagram(dia.DiagramGUID, 0); }catch(e2){} }
        Repository.ReloadDiagram(dia.DiagramID);
        Repository.OpenDiagram(dia.DiagramID);
        log("LISTO: " + DIAG_NOMBRE + "  (" + ELEMS.length + " clases, " + RELS.length + " relaciones)");
    } catch(err){ Session.Output("ERROR: " + err.description); }
}
main();
