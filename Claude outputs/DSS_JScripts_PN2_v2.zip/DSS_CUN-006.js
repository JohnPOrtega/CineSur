/*
 * ============================================================================
 *  Enterprise Architect - JScript
 *  Genera el Diagrama de Secuencia (DSS) del CUN-006
 *  "Registrar solicitud de cotizacion"  (PN2 - CineSur)
 *
 *  ANTES DE EJECUTAR: cerra todos los diagramas abiertos en EA.
 *  Se puede volver a ejecutar: si ya existe el diagrama con el mismo nombre
 *  en el paquete seleccionado, lo borra y lo rehace (idempotente).
 *
 *  COMO USARLO:
 *   1. En el Browser, selecciona el PAQUETE donde queres el diagrama
 *      (por ejemplo "CUN-006 > DSS").
 *   2. Specialize > Scripting. Click derecho en un Script Group >
 *      New JScript Script. Pega TODO este archivo.
 *   3. Click derecho sobre el script > Run Script.
 * ============================================================================
 */

!INC Local Scripts.EAConstants-JScript

// ===================== CONFIG =====================
var DIAG_NOMBRE = "DSS CUN-006 Registrar solicitud de cotizacion";

var LIFELINES = [{"key": "Sup", "nombre": "Supervisor", "tipo": "actor"}, {"key": "F", "nombre": "Presupuestos", "tipo": "boundary"}, {"key": "BProd", "nombre": "BllProducto_14OR", "tipo": "clase"}, {"key": "BProv", "nombre": "BllProveedor_14OR", "tipo": "clase"}, {"key": "BPre", "nombre": "BllPresupuesto_14OR", "tipo": "clase"}, {"key": "BBit", "nombre": "BllBitacora_43BO", "tipo": "clase"}, {"key": "BDV", "nombre": "BllDV_43BO", "tipo": "clase"}, {"key": "DAL", "nombre": "DAL", "tipo": "dal"}];

var MSGS = [{"from": "Sup", "to": "F", "label": "RegistrarSolicitudCotizacion()"}, {"from": "F", "to": "BProd", "label": "ListarEnCritico_14OR()"}, {"from": "BProd", "to": "DAL", "label": "ListarEnCritico_14OR()"}, {"from": "DAL", "to": "DAL", "label": "Leer_43BO(query, parametros)", "self": true}, {"from": "DAL", "to": "BProd", "ret": "List<Producto_14OR>"}, {"from": "BProd", "to": "F", "ret": "List<Producto_14OR>"}, {"from": "F", "to": "BProv", "label": "Listar_14OR()", "gap": 12}, {"from": "BProv", "to": "DAL", "label": "Listar_14OR()"}, {"from": "DAL", "to": "DAL", "label": "Leer_43BO(query, parametros)", "self": true}, {"from": "DAL", "to": "BProv", "ret": "List<Proveedor_14OR>"}, {"from": "BProv", "to": "F", "ret": "List<Proveedor_14OR>"}, {"from": "F", "to": "Sup", "ret": "Presupuestos"}, {"from": "Sup", "to": "F", "label": "RegistrarProveedor(cuit, razonSocial, telefono, email)  [CUN-008]", "gap": 30}, {"from": "F", "to": "BProv", "label": "Alta_14OR(proveedor)"}, {"from": "BProv", "to": "DAL", "label": "Alta_14OR(proveedor)"}, {"from": "DAL", "to": "DAL", "label": "Escribir_43BO(query, parametros)", "self": true}, {"from": "DAL", "to": "BProv", "ret": "bool"}, {"from": "BProv", "to": "BBit", "label": "GuardarLog_43BO(modulo, evento, criticidad)", "gap": 10}, {"from": "BBit", "to": "DAL", "label": "GuardarLog_43BO(bitacora)"}, {"from": "DAL", "to": "DAL", "label": "Escribir_43BO(query, parametros)", "self": true}, {"from": "BProv", "to": "BDV", "label": "RecalcularTrasPersistir_43BO()", "gap": 10}, {"from": "BDV", "to": "DAL", "label": "RecalcularTrasPersistir(tabla, dvv, dvh)"}, {"from": "DAL", "to": "DAL", "label": "Escribir_43BO(query, parametros)", "self": true}, {"from": "BProv", "to": "F", "ret": "bool", "gap": 10}, {"from": "F", "to": "Sup", "ret": "Message"}, {"from": "Sup", "to": "F", "label": "SeleccionarProveedor(idProveedor)", "gap": 30}, {"from": "Sup", "to": "F", "label": "AgregarRenglon(producto, cantidad)", "gap": 30}, {"from": "F", "to": "F", "label": "new DetallePresupuesto_14OR()", "self": true}, {"from": "Sup", "to": "F", "label": "PedirPresupuesto()", "gap": 30}, {"from": "F", "to": "BPre", "label": "PedirPresupuesto_14OR(idProveedor, renglones)", "gap": 30}, {"from": "BPre", "to": "DAL", "label": "PedirPresupuesto_14OR(presupuesto)"}, {"from": "DAL", "to": "DAL", "label": "Escribir_43BO(query, parametros)", "self": true}, {"from": "DAL", "to": "BPre", "ret": "bool"}, {"from": "BPre", "to": "BBit", "label": "GuardarLog_43BO(modulo, evento, criticidad)", "gap": 10}, {"from": "BBit", "to": "DAL", "label": "GuardarLog_43BO(bitacora)"}, {"from": "DAL", "to": "DAL", "label": "Escribir_43BO(query, parametros)", "self": true}, {"from": "BPre", "to": "BDV", "label": "RecalcularTrasPersistir_43BO()", "gap": 10}, {"from": "BDV", "to": "DAL", "label": "RecalcularTrasPersistir(tabla, dvv, dvh)"}, {"from": "DAL", "to": "DAL", "label": "Escribir_43BO(query, parametros)", "self": true}, {"from": "BPre", "to": "F", "ret": "bool", "gap": 10}, {"from": "F", "to": "Sup", "ret": "Message"}, {"from": "F", "to": "Sup", "ret": "Message", "gap": 24}];

var FRAGS = [{"op": "opt", "guard": "el proveedor no existe (esc. alt. 3.1) -> CUN-008", "desde": 12, "hasta": 24}, {"op": "loop", "guard": "por cada producto a reponer", "desde": 26, "hasta": 27}, {"op": "alt", "guard": "cantidad valida ( > 0 )", "desde": 29, "hasta": 41, "divisor": 41, "elseGuard": "cantidad invalida (esc. alt. 4.1)"}];

// ===================== GEOMETRIA =====================
var X0        = 30;
var X_STEP    = 130;
var LL_W      = 100;
var TOP       = -50;
var BOT       = -1100;
var Y_FIRST   = -110;
var Y_STEP    = 26;
var SELF_H    = 16;
var FRAG_PADX = 16;
var FRAG_TOPH = 26;

// ===================== HELPERS =====================
function log(s) { Session.Output("[CUN-006] " + s); }

function sqlEsc(s) {
    var out = ""; var i;
    for (i = 0; i < s.length; i++) {
        var ch = s.charAt(i);
        if (ch == "'") out += "''"; else out += ch;
    }
    return out;
}
function exec(sql) { Repository.Execute(sql); }

// ===================== MAIN =====================
function main()
{
    var pkg as EA.Package;
    pkg = Repository.GetTreeSelectedPackage();
    if (pkg == null) {
        Session.Prompt("Primero selecciona en el arbol el paquete donde crear el diagrama.", promptOK);
        return;
    }
    try {
        var k;
        for (k = 0; k < pkg.Diagrams.Count; k++) {
            var dx as EA.Diagram;
            dx = pkg.Diagrams.GetAt(k);
            if (dx.Name == DIAG_NOMBRE) {
                pkg.Diagrams.DeleteAt(k, false);
                pkg.Diagrams.Refresh();
                log("Diagrama previo borrado (re-ejecucion).");
                break;
            }
        }

        var dia as EA.Diagram;
        dia = pkg.Diagrams.AddNew(DIAG_NOMBRE, "Sequence");
        dia.Update();
        pkg.Diagrams.Refresh();
        var DID = dia.DiagramID;
        log("Diagrama creado, ID=" + DID);

        var elem = {};
        var i;
        for (i = 0; i < LIFELINES.length; i++) {
            var L = LIFELINES[i];
            var eType = "Sequence";
            if (L.tipo == "actor") eType = "Actor";
            var e as EA.Element;
            e = pkg.Elements.AddNew(L.nombre, eType);
            if (L.tipo == "boundary") e.Stereotype = "boundary";
            e.Update();
            pkg.Elements.Refresh();
            elem[L.key] = e.ElementID;

            var xL = X0 + i * X_STEP;
            var xR = xL + LL_W;
            var dob as EA.DiagramObject;
            dob = dia.DiagramObjects.AddNew("l=" + xL + ";r=" + xR + ";t=" + TOP + ";b=" + BOT + ";", "");
            dob.ElementID = e.ElementID;
            dob.Update();
        }
        dia.DiagramObjects.Refresh();
        log("Lifelines creados: " + LIFELINES.length);

        function cx(key) {
            var j;
            for (j = 0; j < LIFELINES.length; j++) {
                if (LIFELINES[j].key == key) return X0 + j * X_STEP + LL_W / 2;
            }
            return X0;
        }

        var y = Y_FIRST;
        var yOf = [];
        for (i = 0; i < MSGS.length; i++) {
            var m = MSGS[i];
            if (m.gap) y -= m.gap;
            yOf[i] = y;

            var srcId = elem[m.from];
            var dstId = elem[m.to];
            var srcEl as EA.Element;
            srcEl = Repository.GetElementByID(srcId);
            var c as EA.Connector;
            c = srcEl.Connectors.AddNew(m.label ? m.label : "", "Sequence");
            c.SupplierID = dstId;
            c.Update();
            srcEl.Connectors.Refresh();
            var CID = c.ConnectorID;

            var pdata4 = "0";
            var retval = "retval=void;";
            var nameSql = m.label ? sqlEsc(m.label) : "";
            if (m.ret) {
                pdata4 = "1";
                retval = "retval=" + m.ret + ";";
                nameSql = "";
            }
            var y0 = y;
            var y1 = m.self ? (y - SELF_H) : y;

            var sql = "UPDATE t_connector SET "
                + "DiagramID=" + DID + ", "
                + "SeqNo=" + (i + 1) + ", "
                + "PtStartY=" + y0 + ", PtEndY=" + y1 + ", "
                + "Name='" + nameSql + "', "
                + "PDATA1='Synchronous', "
                + "PDATA2='" + retval + "', "
                + "PDATA3='Call', "
                + "PDATA4='" + pdata4 + "' "
                + "WHERE Connector_ID=" + CID + ";";
            exec(sql);

            y -= Y_STEP;
            if (m.self) y -= SELF_H;
        }
        log("Mensajes creados: " + MSGS.length);

        for (i = 0; i < FRAGS.length; i++) {
            var fr = FRAGS[i];
            var fe as EA.Element;
            fe = pkg.Elements.AddNew(fr.op, "InteractionFragment");
            fe.Update();
            pkg.Elements.Refresh();

            var yTop = yOf[fr.desde] + FRAG_TOPH;
            var yBot = yOf[fr.hasta] - Y_STEP;
            var minX = 999999, maxX = -999999;
            var r;
            for (r = fr.desde; r <= fr.hasta; r++) {
                var a = cx(MSGS[r].from), b = cx(MSGS[r].to);
                if (a < minX) minX = a; if (b < minX) minX = b;
                if (a > maxX) maxX = a; if (b > maxX) maxX = b;
            }
            var boxL = minX - FRAG_PADX;
            var boxR = maxX + FRAG_PADX;

            var fdo as EA.DiagramObject;
            fdo = dia.DiagramObjects.AddNew("l=" + boxL + ";r=" + boxR + ";t=" + yTop + ";b=" + yBot + ";", "");
            fdo.ElementID = fe.ElementID;
            fdo.Update();

            var nt = 4;
            if (fr.op == "alt") nt = 0; else if (fr.op == "opt") nt = 1;
            else if (fr.op == "break") nt = 2; else if (fr.op == "par") nt = 3;
            exec("UPDATE t_object SET NType=" + nt + ", PDATA1='" + DID + "', Name='" + sqlEsc(fr.op) + "' WHERE Object_ID=" + fe.ElementID + ";");
            log("Fragmento " + fr.op + " [" + fr.guard + "] creado.");
        }
        dia.DiagramObjects.Refresh();

        var yEnd = y - 40;
        exec("UPDATE t_diagramobjects SET RectBottom=" + yEnd + " WHERE Diagram_ID=" + DID
             + " AND Object_ID IN (SELECT Object_ID FROM t_object WHERE Object_Type IN ('Sequence','Actor'));");

        Repository.ReloadDiagram(DID);
        Repository.OpenDiagram(DID);
        log("LISTO. Diagrama abierto en el paquete: " + pkg.Name);
    }
    catch (err) {
        Session.Output("ERROR: " + err.description);
    }
}

main();
