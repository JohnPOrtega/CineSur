!INC Local Scripts.EAConstants-JScript

var PKG_NOMBRE  = "DC CUN-008";
var DIAG_NOMBRE = "DC CUN-008 Registrar orden de compra";
var CLASES = [{"k": "FPresupuestos", "nombre": "Presupuestos", "ester": "boundary", "x": 645, "y": 40, "w": 210, "h": 94, "attrs": [], "ops": [{"n": "btnPedir_Click", "t": "void"}, {"n": "btnCargarPrecios_Click", "t": "void"}, {"n": "btnAceptar_Click", "t": "void"}, {"n": "btnRechazar_Click", "t": "void"}]}, {"k": "BllOrdenCompra", "nombre": "BllOrdenCompra_14OR", "ester": "control", "x": 375, "y": 250, "w": 210, "h": 109, "attrs": [], "ops": [{"n": "GenerarDesdePresupuesto_14OR", "t": "int"}, {"n": "PagarCompra_14OR", "t": "void"}, {"n": "RegistrarIngresoMercaderia_14OR", "t": "int"}, {"n": "Listar_14OR", "t": "List<OrdenCompra_14OR>"}, {"n": "ObtenerDetalle_14OR", "t": "List<DetalleOrdenCompra_14OR>"}]}, {"k": "BllBitacora", "nombre": "BllBitacora_43BO", "ester": "control", "x": 645, "y": 250, "w": 210, "h": 70, "attrs": [], "ops": [{"n": "GuardarLog_43BO", "t": "void"}]}, {"k": "BllDV", "nombre": "BllDV_43BO", "ester": "control", "x": 915, "y": 250, "w": 210, "h": 70, "attrs": [], "ops": [{"n": "RecalcularTrasPersistir_43BO", "t": "void"}]}, {"k": "DalOrdenCompra", "nombre": "DALOrdenCompra_14OR", "ester": "", "x": 510, "y": 470, "w": 210, "h": 109, "attrs": [], "ops": [{"n": "GenerarDesdePresupuesto_14OR", "t": "int"}, {"n": "PagarCompra_14OR", "t": "int"}, {"n": "RegistrarIngresoMercaderia_14OR", "t": "int"}, {"n": "Listar_14OR", "t": "List<OrdenCompra_14OR>"}, {"n": "ObtenerDetalle_14OR", "t": "List<DetalleOrdenCompra_14OR>"}]}, {"k": "DalPresupuesto", "nombre": "DALPresupuesto_14OR", "ester": "", "x": 780, "y": 470, "w": 210, "h": 109, "attrs": [], "ops": [{"n": "PedirPresupuesto_14OR", "t": "int"}, {"n": "CargarCotizacion_14OR", "t": "void"}, {"n": "CambiarEstado_14OR", "t": "int"}, {"n": "Listar_14OR", "t": "List<Presupuesto_14OR>"}, {"n": "ObtenerDetalle_14OR", "t": "List<DetallePresupuesto_14OR>"}]}, {"k": "OrdenCompra", "nombre": "OrdenCompra_14OR", "ester": "entity", "x": 240, "y": 690, "w": 210, "h": 199, "attrs": [{"n": "IdOrdenCompra_14OR", "t": "int"}, {"n": "NumeroOrden_14OR", "t": "int"}, {"n": "IdProveedor_14OR", "t": "int"}, {"n": "IdPresupuesto_14OR", "t": "int"}, {"n": "FechaEmision_14OR", "t": "DateTime"}, {"n": "Estado_14OR", "t": "string"}, {"n": "Importe_14OR", "t": "double"}, {"n": "FechaPago_14OR", "t": "DateTime?"}, {"n": "NumeroRemito_14OR", "t": "string"}, {"n": "FechaRecepcion_14OR", "t": "DateTime?"}, {"n": "Detalles", "t": "List<DetalleOrdenCompra_14OR>"}], "ops": []}, {"k": "DetalleOrdenCompra", "nombre": "DetalleOrdenCompra_14OR", "ester": "entity", "x": 510, "y": 690, "w": 210, "h": 139, "attrs": [{"n": "IdDetalleOrdenCompra_14OR", "t": "int"}, {"n": "IdOrdenCompra_14OR", "t": "int"}, {"n": "IdProducto_14OR", "t": "int"}, {"n": "NombreProducto_14OR", "t": "string"}, {"n": "Cantidad_14OR", "t": "int"}, {"n": "PrecioCosto_14OR", "t": "double"}, {"n": "Subtotal_14OR", "t": "double"}], "ops": []}, {"k": "Presupuesto", "nombre": "Presupuesto_14OR", "ester": "entity", "x": 780, "y": 690, "w": 210, "h": 139, "attrs": [{"n": "IdPresupuesto_14OR", "t": "int"}, {"n": "NumeroPresupuesto_14OR", "t": "int"}, {"n": "IdProveedor_14OR", "t": "int"}, {"n": "NombreProveedor_14OR", "t": "string"}, {"n": "FechaPedido_14OR", "t": "DateTime"}, {"n": "Estado_14OR", "t": "string"}, {"n": "Detalles", "t": "List<DetallePresupuesto_14OR>"}], "ops": []}, {"k": "DetallePresupuesto", "nombre": "DetallePresupuesto_14OR", "ester": "entity", "x": 1050, "y": 690, "w": 210, "h": 139, "attrs": [{"n": "IdDetallePresupuesto_14OR", "t": "int"}, {"n": "IdPresupuesto_14OR", "t": "int"}, {"n": "IdProducto_14OR", "t": "int"}, {"n": "NombreProducto_14OR", "t": "string"}, {"n": "Cantidad_14OR", "t": "int"}, {"n": "PrecioCotizado_14OR", "t": "double"}, {"n": "Subtotal_14OR", "t": "double"}], "ops": []}];
var RELS   = [{"de": "FPresupuestos", "a": "BllOrdenCompra", "tipo": "Association"}, {"de": "BllOrdenCompra", "a": "DalOrdenCompra", "tipo": "Association"}, {"de": "DalOrdenCompra", "a": "OrdenCompra", "tipo": "Dependency"}, {"de": "DalOrdenCompra", "a": "DetalleOrdenCompra", "tipo": "Dependency"}, {"de": "DalPresupuesto", "a": "Presupuesto", "tipo": "Dependency"}, {"de": "DalPresupuesto", "a": "DetallePresupuesto", "tipo": "Dependency"}, {"de": "BllOrdenCompra", "a": "BllBitacora", "tipo": "Dependency"}, {"de": "BllOrdenCompra", "a": "BllDV", "tipo": "Dependency"}];

function pos(l,t,r,b){ return "l="+l+";r="+r+";t="+t+";b="+b+";"; }
function log(s){ Session.Output("[DC] "+s); }

function main(){
    var padre as EA.Package;
    padre = Repository.GetTreeSelectedPackage();
    if (padre == null){ Session.Prompt("Selecciona en el arbol el paquete donde crear el diagrama.", promptOK); return; }
    try{
        var i, j;
        // idempotente: borro el subpaquete si ya lo cree antes
        for (i=0; i<padre.Packages.Count; i++){
            var px as EA.Package; px = padre.Packages.GetAt(i);
            if (px.Name == PKG_NOMBRE){ padre.Packages.DeleteAt(i,false); padre.Packages.Refresh(); break; }
        }
        var pkg as EA.Package; pkg = padre.Packages.AddNew(PKG_NOMBRE,""); pkg.Update(); padre.Packages.Refresh();
        var dia as EA.Diagram; dia = pkg.Diagrams.AddNew(DIAG_NOMBRE,"Class"); dia.Update(); pkg.Diagrams.Refresh();
        var DID = dia.DiagramID;

        var id = {};
        for (i=0; i<CLASES.length; i++){
            var c = CLASES[i];
            var e as EA.Element; e = pkg.Elements.AddNew(c.nombre,"Class");
            if (c.ester != "") e.Stereotype = c.ester;
            e.Update(); pkg.Elements.Refresh();
            id[c.k] = e.ElementID;

            for (j=0; j<c.attrs.length; j++){
                var at as EA.Attribute; at = e.Attributes.AddNew(c.attrs[j].n, c.attrs[j].t);
                at.Visibility = "Public"; at.Update();
            }
            e.Attributes.Refresh();
            for (j=0; j<c.ops.length; j++){
                var op as EA.Method; op = e.Methods.AddNew(c.ops[j].n, c.ops[j].t);
                op.Visibility = "Public"; op.Update();
            }
            e.Methods.Refresh();

            var dob as EA.DiagramObject;
            dob = dia.DiagramObjects.AddNew(pos(c.x, c.y, c.x+c.w, c.y+c.h), "");
            dob.ElementID = e.ElementID; dob.Update();
        }
        dia.DiagramObjects.Refresh();
        log("Clases creadas: " + CLASES.length);

        for (i=0; i<RELS.length; i++){
            var r = RELS[i];
            var src as EA.Element; src = Repository.GetElementByID(id[r.de]);
            var con as EA.Connector; con = src.Connectors.AddNew("", r.tipo);
            con.SupplierID = id[r.a];
            con.Update(); src.Connectors.Refresh();
        }
        log("Relaciones: " + RELS.length);

        Repository.ReloadDiagram(DID);
        Repository.OpenDiagram(DID);
        Repository.RefreshModelView(padre.PackageID);
        log("LISTO. Diagrama '" + DIAG_NOMBRE + "' en " + padre.Name + " > " + PKG_NOMBRE);
    } catch (err){ Session.Output("ERROR: " + err.description); }
}
main();
