!INC Local Scripts.EAConstants-JScript

var PKG_NOMBRE  = "DC CUN-009";
var DIAG_NOMBRE = "DC CUN-009 Registrar proveedor";
var CLASES = [{"k": "FProveedores", "nombre": "Proveedores", "ester": "boundary", "x": 645, "y": 40, "w": 210, "h": 79, "attrs": [], "ops": [{"n": "btnGuardar_Click", "t": "void"}, {"n": "btnEliminar_Click", "t": "void"}, {"n": "CargarGrilla_14OR", "t": "void"}]}, {"k": "BllProveedor", "nombre": "BllProveedor_14OR", "ester": "control", "x": 375, "y": 250, "w": 210, "h": 94, "attrs": [], "ops": [{"n": "ListarProveedor_14OR", "t": "List<Proveedor_14OR>"}, {"n": "AltaProveedor_14OR", "t": "int"}, {"n": "ModificarProveedor_14OR", "t": "int"}, {"n": "BajaProveedor_14OR", "t": "int"}]}, {"k": "BllBitacora", "nombre": "BllBitacora_43BO", "ester": "control", "x": 645, "y": 250, "w": 210, "h": 70, "attrs": [], "ops": [{"n": "GuardarLog_43BO", "t": "void"}]}, {"k": "BllDV", "nombre": "BllDV_43BO", "ester": "control", "x": 915, "y": 250, "w": 210, "h": 70, "attrs": [], "ops": [{"n": "RecalcularTrasPersistir_43BO", "t": "void"}]}, {"k": "DalProveedor", "nombre": "DALProveedor_14OR", "ester": "", "x": 645, "y": 470, "w": 210, "h": 94, "attrs": [], "ops": [{"n": "ListarProveedor_14OR", "t": "List<Proveedor_14OR>"}, {"n": "AltaProveedor_14OR", "t": "int"}, {"n": "ModificarProveedor_14OR", "t": "int"}, {"n": "BajaProveedor_14OR", "t": "int"}]}, {"k": "Proveedor", "nombre": "Proveedor_14OR", "ester": "entity", "x": 645, "y": 690, "w": 210, "h": 109, "attrs": [{"n": "IdProveedor_14OR", "t": "int"}, {"n": "Nombre_14OR", "t": "string"}, {"n": "Telefono_14OR", "t": "string"}, {"n": "Email_14OR", "t": "string"}, {"n": "Activo_14OR", "t": "bool"}], "ops": []}];
var RELS   = [{"de": "FProveedores", "a": "BllProveedor", "tipo": "Association"}, {"de": "BllProveedor", "a": "DalProveedor", "tipo": "Association"}, {"de": "DalProveedor", "a": "Proveedor", "tipo": "Dependency"}, {"de": "BllProveedor", "a": "Proveedor", "tipo": "Dependency"}, {"de": "BllProveedor", "a": "BllBitacora", "tipo": "Dependency"}, {"de": "BllProveedor", "a": "BllDV", "tipo": "Dependency"}];

function pos(l,t,r,b){ return "l="+l+";r="+r+";t="+t+";b="+b+";"; }
function log(s){ Session.Output("[DC] "+s); }

function main(){
    var padre as EA.Package;
    padre = Repository.GetTreeSelectedPackage();
    if (padre == null){ Session.Prompt("Selecciona en el arbol el paquete donde crear el diagrama.", promptOK); return; }
    try{
        var i, j;
        // idempotente: borro el subpaquete si ya lo cree antes
        for (i=0; i<padre.Packages.Count; i++){
            var px as EA.Package; px = padre.Packages.GetAt(i);
            if (px.Name == PKG_NOMBRE){ padre.Packages.DeleteAt(i,false); padre.Packages.Refresh(); break; }
        }
        var pkg as EA.Package; pkg = padre.Packages.AddNew(PKG_NOMBRE,""); pkg.Update(); padre.Packages.Refresh();
        var dia as EA.Diagram; dia = pkg.Diagrams.AddNew(DIAG_NOMBRE,"Class"); dia.Update(); pkg.Diagrams.Refresh();
        var DID = dia.DiagramID;

        var id = {};
        for (i=0; i<CLASES.length; i++){
            var c = CLASES[i];
            var e as EA.Element; e = pkg.Elements.AddNew(c.nombre,"Class");
            if (c.ester != "") e.Stereotype = c.ester;
            e.Update(); pkg.Elements.Refresh();
            id[c.k] = e.ElementID;

            for (j=0; j<c.attrs.length; j++){
                var at as EA.Attribute; at = e.Attributes.AddNew(c.attrs[j].n, c.attrs[j].t);
                at.Visibility = "Public"; at.Update();
            }
            e.Attributes.Refresh();
            for (j=0; j<c.ops.length; j++){
                var op as EA.Method; op = e.Methods.AddNew(c.ops[j].n, c.ops[j].t);
                op.Visibility = "Public"; op.Update();
            }
            e.Methods.Refresh();

            var dob as EA.DiagramObject;
            dob = dia.DiagramObjects.AddNew(pos(c.x, c.y, c.x+c.w, c.y+c.h), "");
            dob.ElementID = e.ElementID; dob.Update();
        }
        dia.DiagramObjects.Refresh();
        log("Clases creadas: " + CLASES.length);

        for (i=0; i<RELS.length; i++){
            var r = RELS[i];
            var src as EA.Element; src = Repository.GetElementByID(id[r.de]);
            var con as EA.Connector; con = src.Connectors.AddNew("", r.tipo);
            con.SupplierID = id[r.a];
            con.Update(); src.Connectors.Refresh();
        }
        log("Relaciones: " + RELS.length);

        Repository.ReloadDiagram(DID);
        Repository.OpenDiagram(DID);
        Repository.RefreshModelView(padre.PackageID);
        log("LISTO. Diagrama '" + DIAG_NOMBRE + "' en " + padre.Name + " > " + PKG_NOMBRE);
    } catch (err){ Session.Output("ERROR: " + err.description); }
}
main();
